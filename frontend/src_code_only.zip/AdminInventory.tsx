export default function AdminInventory() {
  return <div style={{ padding: "2rem" }}>Inventory Management — Coming in Phase 3</div>;
}