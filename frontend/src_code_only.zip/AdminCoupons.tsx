export default function AdminCoupons() {
  return <div style={{ padding: "2rem" }}>Coupon Management — Coming in Phase 3</div>;
}