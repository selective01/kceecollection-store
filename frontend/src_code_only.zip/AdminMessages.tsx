export default function AdminMessages() {
  return <div style={{ padding: "2rem" }}>Customer Messages — Coming in Phase 3</div>;
}