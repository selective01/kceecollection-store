// models/Message.js — Phase 4 Backend
import mongoose from "mongoose";

const messageSchema = new mongoose.Schema(
  {
    name:     { type: String, required: true, trim: true },
    email:    { type: String, required: true, trim: true },
    subject:  { type: String, required: true, trim: true },
    body:     { type: String, required: true },
    read:     { type: Boolean, default: false },
    replied:  { type: Boolean, default: false },
  },
  { timestamps: true }
);

export default mongoose.model("Message", messageSchema);
